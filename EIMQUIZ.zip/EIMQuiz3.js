const quizData = [
    {
        question: "What  tools are plier-like  used to remove the insulating outer sheath?",
        a: "Wire Strippers",
        b: "Hacksaw",
        c: "Hammer",
        d: "None of the above",
        correct: "a",
    },
    {
        question: "What are one of the most traditional of tools but are still indispensable for most electricians ?",
        a: "Electrical Tape",
        b: "Screwdrivers",
        c: "Wire",
        d: " Claw Hammer",
        correct: "b",
    },
    {
        question: "What tools that has been with us for a long time?",
        a: "Insulated Pliers",
        b: "Electrical Tape",
        c: "Block",
        d: "Schematic",
        correct: "a",
    },
    {
        question: "It is used to insulate wires or other items that conduct electricity.?",
        a: "Electrical Tape",
        b: "Screwdriver",
        c: "Pliers",
        d: "none of the above",
        correct: "a",
    },

    {
        question: "These versatile tools feature steel blades and cut through standard wiring easily?",
        a: "Side Cutter",
        b: "Cable Cutter",
        c: "Tape",
        d: "none of the above",
        correct: "b",
    },

    {
        question: "A standard hammer on one side of the tool?",
        a: "Block",
        b: "Direct ",
        c: "Claw",
        d: "none of the above",
        correct: "c",
    },

    {
        question: "These are another toolkit standby with a relatively self-explanatory name?",
        a: "Voltage Tester",
        b: "Multi-Voltage",
        c: "Line Tester",
        d: "Logic Tester",
        correct: "a",
    },

    {
        question: "These are not just a specialist professional tool – they are in fact familiar to most of us.?",
        a: "Safety Knife",
        b: "Side Knife",
        c: "Line Knife",
        d: "Chef Knife",
        correct: "a",
    },



];
console.log(typeof(quizData));

const quiz= document.getElementById('quiz')
const answerEls = document.querySelectorAll('.answer')
const questionEl = document.getElementById('question')
const a_text = document.getElementById('a_text')
const b_text = document.getElementById('b_text')
const c_text = document.getElementById('c_text')
const d_text = document.getElementById('d_text')
const submitBtn = document.getElementById('submit')


let currentQuiz = 0
let score = 0

loadQuiz()

function loadQuiz() {

    deselectAnswers()

    const currentQuizData = quizData[currentQuiz]

    questionEl.innerText = currentQuizData.question
    a_text.innerText = currentQuizData.a
    b_text.innerText = currentQuizData.b
    c_text.innerText = currentQuizData.c
    d_text.innerText = currentQuizData.d
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false)
}

function getSelected() {
    let answer
    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id
        }
    })
    return answer
}


submitBtn.addEventListener('click', () => {
    const answer = getSelected()
    if(answer) {
       if(answer === quizData[currentQuiz].correct) {
           score++
       }

       currentQuiz++

       if(currentQuiz < quizData.length) {
           loadQuiz()
       } else {
           quiz.innerHTML = `
           <h2>You answered ${score}/${quizData.length} questions correctly</h2>

           <button onclick="location.reload()">Reload</button>
           `
       }
    }
})